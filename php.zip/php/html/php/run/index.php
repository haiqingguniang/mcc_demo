<?php
/**
 * Created by IntelliJ IDEA.
 * User: szc
 * Date: 16/5/24
 * Time: 上午10:39
 */

include "../include/config.php";
include "../include/JPHP.php";
include "../include/errCode.php";


$_CONTROL = null;
$s = $_SERVER["REQUEST_URI"];
$temp = explode('?', $s);
$url = explode('/', $temp[0]);
$num = count($url);
for ($i = 0; $i < $num - 1; $i++) {

    $_CONTROL['core'] = $url[$i];
    $_CONTROL['method'] = $url[$i + 1];
}

$className=$_CONTROL['core'];
include $className.".php";
$class=new $className;
$method = $_CONTROL['method'];
if(method_exists($class,$method)) {
    $class->$method();
}
else{
    @header("http/1.1 404 not found");
    @header("status: 404 not found");
    //include("404.html");
    exit();
}


?>
