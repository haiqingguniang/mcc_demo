<?php

header("Access-Control-Allow-Origin:*");

header('Access-Control-Allow-Methods:POST,GET');

header('Access-Control-Allow-Headers:x-requested-with, content-type,token');
   /**
   * 
   */
class user
{
  private function initCurl($url, $method, $postfields) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,

      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => $method,
      CURLOPT_POSTFIELDS => $postfields,
      CURLOPT_HTTPHEADER => array(
        "Content-Type: application/x-www-form-urlencoded",
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);

    return array($err, $response);
  }

  public function getcode() {
    $url = "https://test.api.mofangvr.com/cubekit/verification_code";
    $method = "POST";
    $postfields = "tel=".$_POST["tel"]."&area=".$_POST["area"];
    // $postfields= "tel=17826800630&area=86";
    $result = $this->initCurl($url, $method, $postfields);

    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      echo $result[1];
    }
  }
      
  public function gettoken(){
    
    $url = "https://test.api.mofangvr.com/cubekit/token?grant_type=client_credential&appid=MCC05ca87f2ccbcca56&secret=2b1c955012d790ea932e603b9e40c959";
    $method = "GET";
    $postfields = "access_token=&tel=&area=&code=&undefined=";
    $result = $this->initCurl($url, $method, $postfields);

    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      // echo $response;
      $myfile = fopen("user.txt", "w");
      $txt=$result[1];
      $jsondata=json_decode($result[1]);
      $atr=json_encode($jsondata->result);
      fwrite($myfile,$atr);
    }
  }

  public function authlogin(){
    self::gettoken();

    $file=fopen("user.txt","r");
    $txt=fread($file,filesize("user.txt"));
    $jsondata=json_decode($txt);
    $access_token_txt=json_encode($jsondata->access_token);
    $access_token= preg_replace('/"/i','',$access_token_txt);

    $url = "https://test.api.mofangvr.com/cubekit/usertoken/auth_login";
    $method = "POST";
    $postfields = "access_token=".$access_token."&tel=".$_POST["tel"]."&area=".$_POST["area"]."&code=".$_POST["code"];
    // $postfields = "access_token=8e7f31022e6c1ba95587ef3625668b77&tel=17826800630&area=86&code=973065";
    $result = $this->initCurl($url, $method, $postfields);
    
    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      echo $result[1];
    }
  }

  //获取token
  public function createtoken(){

    $file=fopen("user.txt","r");
    $txt=fread($file,filesize("user.txt"));
    $jsondata=json_decode($txt);
    $access_token_txt=json_encode($jsondata->access_token);
    $access_token= preg_replace('/"/i','',$access_token_txt);

    $url = "https://test.api.mofangvr.com/cubekit/token/create";
    $method = "POST";
    $postfields = "access_token=".$access_token."&openid=".$_POST["openid"]."&coin=CLV&amount=1000&tag=ab&description=ab";
    // $postfields = "access_token=8e7f31022e6c1ba95587ef3625668b77&openid=a07e2052b13d602da6022e533f3bed3d&coin=CLV&amount=1000&tag=ab&description=ab";
    $result = $this->initCurl($url, $method, $postfields);
    
    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      echo $result[1];
    }
  }

      //获取交易对的信息
  public function getLatestMarket(){

    $url = "https://test.api.mofangvr.com/cubekit/getLatestMarket";
    $method = "POST";
    $postfields = "market=CLVMCC&period=86400";
    $result = $this->initCurl($url, $method, $postfields);
    
    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      echo $result[1];
    }
  }

  //获取k线数据
  public function getkline(){

    $url = "https://test.api.mofangvr.com/cubekit/market/kline";
    $method = "POST";
    $postfields = "market=CLVMCC&start=".$_POST['start']."&end=".$_POST['end']."&interval=".$_POST['interval'];
    $result = $this->initCurl($url, $method, $postfields);

    if ($result[0]) {
      echo "cURL Error #:" . $result[0];
    } else {
      echo $result[1];
    }
  }
}

   
