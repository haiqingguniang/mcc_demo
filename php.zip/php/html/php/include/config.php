﻿<?php
/**
 * Created by IntelliJ IDEA.
 * User: szc
 * Date: 16/1/18
 * Time: 下午5:24
 */

header("content-type:text/html; charset=utf-8");
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('Asia/Shanghai');
$IP=$_SERVER['REMOTE_ADDR'];
function gettime(){
    $time=date('Y-m-j:H:i:s');
    if(strlen($time)==17)
        return date('Y-m-0j:H:i:s');
    else return $time;
}
$lifeTime = 24 * 3600;
session_set_cookie_params($lifeTime);
session_start();

$time=gettime();

function filters($post_array){
    $correct=0;
    foreach ($post_array as $key => $value){ 
        $pattern = "/(&amp;|&quot|&lt;|&gt;|'|<|>|\||\"|\?|;|`)+/";
        if (is_array($value)){
            foreach ($value as $keykey=>$valuevalue){
                if (preg_match($pattern, $valuevalue, $matches) || preg_match($pattern, $keykey, $matches)) {
                    $correct=1;
                }
            }
        }else{
            if (preg_match($pattern, $value, $matches) || preg_match($pattern, $key, $matches)) {
                $correct=1;
            }
        }
    }
    return $correct;
}

function trimall($str)//删除空格
{
    $qian=array(" ","\t","\n","\r","\\",";","\"","'","%","/");
    $hou=array("","","","","","","","","","","");
    return str_replace($qian,$hou,$str);
}

//获取毫秒级的时间戳,秒级时间戳为10位,毫秒级为13位
function getMillisecond() {
    list($t1, $t2) = explode(' ', microtime());
    return (float)sprintf('%.0f',(floatval($t1)+floatval($t2))*1000);
}

function sort_by_time($array,$flag='create_time'){
    $array=reserve_array($array);
    for ($i=1;$i<count($array);$i++){
        for ($j=$i;$j>0 && $array[$j][$flag]<$array[$j-1][$flag];$j--){
            $temp=$array[$j-1];
            $array[$j-1]=$array[$j];
            $array[$j]=$temp;
        }
    }
    return $array;
}


function reserve_by_time($array,$flag='create_time'){
    $array=reserve_array($array);
    for ($i=1;$i<count($array);$i++){
        for ($j=$i;$j>0 && $array[$j][$flag]>$array[$j-1][$flag];$j--){
            $temp=$array[$j-1];
            $array[$j-1]=$array[$j];
            $array[$j]=$temp;
        }
    }
    return $array;
}

function reserve_array($array){
    $n=count($array);
    $returnArray=null;
    for ($i=$n-1;$i>=0;$i--){
        $returnArray[]=$array[$i];
    }
    return $returnArray;
}

function getNextMonth(){
    if (date('m')==12){
        return 1;
    }else{
        return date('m')+1;
    }
}

function get_every_page($array,$number){
    $list=null;
    for($i=$number;$i<$number+MAXPERPAGE;$i++){
        $list[]=$array[$i];
    }
    if (empty($list[0])){
        return null;
    }else{
        return $list;
    }

}
?>
