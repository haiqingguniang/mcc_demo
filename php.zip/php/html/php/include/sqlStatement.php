<?php

/**
 * Created by IntelliJ IDEA.
 * User: yizhangfang
 * Date: 16-7-11
 * Time: 下午7:21
 */

class sqlStatement
{
    /**
     * insert语句的拼接
     * @param $tableName 传入一个表名字符串
     * @param $array 键值对　字段名和字段值
     * @return string 返回sql语句
     */
    public static function insertDataSQL($tableName,$array){

        $sql="INSERT INTO `$tableName` (";
        $lastSql=" VALUE (";
        foreach ($array as $key=>$value){
            $sql=$sql."`$key` ,";
            $lastSql=$lastSql."'$value' ,";
        }
        $sql=substr($sql,0,-1);
        $lastSql=substr($lastSql,0,-1);
        $sql=$sql.")".$lastSql.")";
        return $sql;
    }

    /**
     * update语句的拼接
     * @param $tableName 传入一个表名字符串
     * @param $array 键值对　字段名和字段值
     * @param $where null为更新整个表，数组为要更新的条目条件
     * @return string 返回sql语句
     */
    public static function updateDataSQL($tableName,$array,$where=null){
        $sql="UPDATE `$tableName` SET ";
        foreach ($array as $key=>$value){
            $sql=$sql."`$key`='$value',";
        }
        $sql=substr($sql,0,-1);
        return $sql.sqlStatement::setWhere($where);
    }


    /**
     * delete语句的拼接
     * @param $tableName 传入一个表名字符串
     * @param null $where null为删除整个表，数组为要删除的条目条件
     * @return string 返回sql语句
     */
    public static function deleteDataSQL($tableName,$where=null){
        $sql="DELETE FROM `$tableName`";
        if (isset($where)){
            return $sql.sqlStatement::setWhere($where);
        }else{
            return $sql;
        }
    }

    /**
     *
     * insert语句的拼接
     * @param $tableName 传入一个表名字符串或数组
     * @param null $array null为查找所有字段，数组为要筛选的字段名
     * @param $where null为查找整个表，数组为要筛选条目条件
     * @return string 返回sql语句
     */
    public static function selectDataSQL($tableName,$array=null,$where=null){
        
        $sql="SELECT";
        if(isset($array)){
            if (is_array($array)){
                foreach ($array as $key=>$value){
                    $sql=$sql." `$value` ,";
                }
            }elseif(is_string($array)){
                $sql=$sql." `$array` ";
            }
        }else{
            $sql=$sql." * ";
        }
        $sql=substr($sql,0,-1);
        $sql=$sql." FROM ";

        if (is_array($tableName)){
            foreach ($tableName as $key=>$value) {
                $sql = $sql . " `$value` ,";
            }
        $sql=substr($sql,0,-1);
        }elseif(is_string($tableName)){
            $sql=$sql." $tableName ";
        }
        return $sql.sqlStatement::setWhere($where);


    }

    /**
     * 拼接where后的语句
     * @param $array 键值对　字段名和字段值
     * @return string 返回sql语句
     */
    public static function setWhere($array=null){
        if (!empty($array)){
            $sql=" WHERE ";
        }
        foreach ($array as $key=>$value){
            $sql=$sql." `$key`='$value' and ";
        }
        if (!empty($array)){
            $sql=substr($sql,0,-4);
        }
        return $sql;
    }
   

    


    

}