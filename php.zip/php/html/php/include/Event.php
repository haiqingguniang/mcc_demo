<?php

/**
 * Created by IntelliJ IDEA.
 * User: yizhangfang
 * Date: 16-7-26
 * Time: 下午2:24
 */

class Event
{

    /**
     * 监听函数返回值以执行或返回或输出各种值，减少了if的使用
     * 如果是数组　一般是select拉取的数据直接返回，如果是字符串，一般是tax23231,su1234214这种假主码，也直接返回，
     * 如果是数字,可能是主码id直接返回，如果是错误码,输出错误信息,退出系统
     * @param $classname
     * @param $args
     * @return mixed
     */
    public static function listen($classname,$args1,$args2=null){
        $result=call_user_func_array($classname,array($args1,$args2));
        if (empty($result)){
            return null;
        }elseif (is_array($result)){
            return $result;
        }elseif(!is_numeric($result)){
            return $result;
        }

        switch ($result){
            case 0:
                break;
            case -1:
                $data['errcode'] = -1;
                $data['msg']=errCode::getErrText(-1);
                echo json_encode($data);
                exit;
            case -1001:
                $data['errcode'] = -1001;
                $data['msg']=errCode::getErrText(-1001);
                echo json_encode($data);
                exit;
            case -1002:
                $data['errcode'] = -1002;
                $data['msg']=errCode::getErrText(-1002);
                echo json_encode($data);
                exit;
            case -1003:
                $data['errcode'] = -1003;
                $data['msg']=errCode::getErrText(-1003);
                echo json_encode($data);
                exit;
            case -1004:
                $data['errcode'] = -1004;
                $data['msg']=errCode::getErrText(-1004);
                echo json_encode($data);
                exit;
            case -1005:
                $data['errcode'] = -1005;
                $data['msg']=errCode::getErrText(-1005);
                echo json_encode($data);
                exit;
            case -1006:
                $data['errcode'] = -1006;
                $data['msg']=errCode::getErrText(-1006);
                echo json_encode($data);
                exit;
            case -1007:
                $data['errcode'] = -1007;
                $data['msg']=errCode::getErrText(-1007);
                echo json_encode($data);
                exit;
            case -1008:
                $data['errcode'] = -1008;
                $data['msg']=errCode::getErrText(-1008);
                echo json_encode($data);
                exit;

            case -1009:
                $data['errcode'] = -1009;
                $data['msg']=errCode::getErrText(-1009);
                echo json_encode($data);
                exit;
            case -1010:
                $data['errcode'] = -1010;
                $data['msg']=errCode::getErrText(-1010);
                echo json_encode($data);
                exit;
            case -1011:
                $data['errcode'] = -1011;
                $data['msg']=errCode::getErrText(-1011);
                echo json_encode($data);
                exit;
            case -1012:
                $data['errcode'] = -1012;
                $data['msg']=errCode::getErrText(-1012);
                echo json_encode($data);
                exit;
            case -1013:
                $data['errcode'] = -1013;
                $data['msg']=errCode::getErrText(-1013);
                echo json_encode($data);
                exit;
            case -1014:
                $data['errcode'] = -1014;
                $data['msg']=errCode::getErrText(-1014);
                echo json_encode($data);
                exit;
            case -1015:
                $data['errcode'] = -1015;
                $data['msg']=errCode::getErrText(-1015);
                echo json_encode($data);
                exit;
            case -1016:
                $data['errcode'] = -1016;
                $data['msg']=errCode::getErrText(-1016);
                echo json_encode($data);
                exit;
            case -1017:
                $data['errcode'] = -1017;
                $data['msg']=errCode::getErrText(-1017);
                echo json_encode($data);
                exit;
            case -1018:
                $data['errcode'] = -1018;
                $data['msg']=errCode::getErrText(-1018);
                echo json_encode($data);
                exit;
            case -1019:
                $data['errcode'] = -1019;
                $data['msg']=errCode::getErrText(-1019);
                echo json_encode($data);
                exit;
            case -1020:
                $data['errcode'] = -1020;
                $data['msg']=errCode::getErrText(-1020);
                echo json_encode($data);
                exit;
            case -1021:
                $data['errcode'] = -1021;
                $data['msg']=errCode::getErrText(-1021);
                echo json_encode($data);
                exit;
            case -1022:
                $data['errcode'] = -1022;
                $data['msg']=errCode::getErrText(-1022);
                echo json_encode($data);
                exit;
            case -1023:
                $data['errcode'] = -1023;
                $data['msg']=errCode::getErrText(-1023);
                echo json_encode($data);
                exit;
            case -1024:
                $data['errcode'] = -1024;
                $data['msg']=errCode::getErrText(-1024);
                echo json_encode($data);
                exit;
            case -1025:
                $data['errcode'] = -1025;
                $data['msg']=errCode::getErrText(-1025);
                echo json_encode($data);
                exit;
            default:
                return $result;
                break;
        }
    }

}