/**
 * Created by szc on 16/5/24.
 */
var phpPath="http://127.0.0.1/yzf/run/";