<?php

/**
 * Created by IntelliJ IDEA.
 * User: yizhangfang
 * Date: 16-10-10
 * Time: 下午6:01
 */
class Admin_control
{

    private $admin = null;
    private $region = null;
    private $role = null;

    public function __construct()
    {
        $this->admin = new Admin();
        $this->region = new Region();
        $this->role = new Role();
    }

    public function insert_admin()
    {
        $post_array['role_id'] = $_POST['role_id'];
        $post_array['name'] = $_POST['name'];
        $post_array['passwd'] = $_POST['passwd'];
        $post_array['account'] = $_POST['account'];
        $regionlist = $_POST['region'];
        $regionlist = json_decode($regionlist, true);
        if (!filters($post_array) && !filters($regionlist)) {
            $insertMethod = array($this->admin, 'insert_admin');
            $admin_id = Event::listen($insertMethod, $post_array);
            foreach ($regionlist as $key => $value) {
                $insertRegion = array($this->region, 'insert_region');
                Event::listen($insertRegion, array('admin_id' => $admin_id, 'province' => $value));
            }
            $data['errcode'] = 0;
            $data['admin_id'] = $admin_id;
            $data['role_id'] = $post_array['role_id'];
            $data['msg'] = errCode::getErrText(0);
            $this->admin->commit();
            $this->region->commit();
        } else {
            $data['errcode'] = -1006;
            $data['msg'] = errCode::getErrText(-1006);
        }
        echo json_encode($data);
    }

    public function update_admin()
    {
        $post_array['role_id'] = $_POST['role_id'];
        $post_array['id'] = $_POST['admin_id'];
        $post_array['name'] = $_POST['name'];
        $post_array['passwd'] = $_POST['passwd'];
        $post_array['account'] = $_POST['account'];
        $regionlist = $_POST['region'];
        $regionlist = json_decode($regionlist, true);
        if (!filters($post_array) && !filters($regionlist)) {
            $updateMethod = array($this->admin, 'update_admin');
            Event::listen($updateMethod, $post_array, array('id' => $post_array['id']));

            $deleteRegion = array($this->region, 'delete_region');
            Event::listen($deleteRegion, array('admin_id' => $post_array['id']));

            foreach ($regionlist as $key => $value) {
                $insertRegion = array($this->region, 'insert_region');
                Event::listen($insertRegion, array('admin_id' => $post_array['id'], 'province' => $value));
            }
            $this->admin->commit();
            $this->region->commit();
            $data['errcode'] = 0;
            $data['role_id'] = $post_array['role_id'];
            $data['msg'] = errCode::getErrText(0);
        } else {
            $data['errcode'] = -1006;
            $data['msg'] = errCode::getErrText(-1006);
        }
        echo json_encode($data);
    }

    public function select_admin()
    {

        $adminlist = $this->admin->select_admin(null);
        foreach ($adminlist as $key => $value) {
            $record['id'] = $value['id'];
            $record['name'] = $value['name'];
            $record['account'] = $value['account'];
            $record['passwd'] = $value['passwd'];
            $rolelist = $this->role->select_role(array('id' => $value['role_id']));
            $record['role_name'] = $rolelist[0]['name'];
            $regionlist = $this->region->select_region(array('admin_id' => $value['id']));
            $region_detail = null;
            foreach ($regionlist as $keyre => $valuere) {
                $region_detail[] = $valuere['province'];
            }
            $record['region'] = $region_detail;
            $array[] = $record;
        }
        $this->admin->commit();
        $this->region->commit();
        $data['errcode'] = 0;
        $data['adminlist'] = $array;
        $data['msg'] = errCode::getErrText(0);

        echo json_encode($data);
    }


    public function delete_admin(){
        $post_array['id']=$_POST['admin_id'];
        if (!filters($post_array)) {
            $deleteMethod=array($this->admin,'delete_admin');
            Event::listen($deleteMethod,$post_array);
            $this->admin->commit();
            $data['errcode'] = 0;
            $data['msg']=errCode::getErrText(0);
        }else{
            $data['errcode'] = -1006;
            $data['msg']=errCode::getErrText(-1006);
        }
        echo json_encode($data);
    }



    public function select_one_admin()
    {
        $post_array['id'] = $_POST['admin_id'];
        if (!filters($post_array)) {
            $adminlist = $this->admin->select_admin(null);
            foreach ($adminlist as $key => $value) {
                $record['id'] = $post_array['id'];
                $record['name'] = $value['name'];
                $record['account'] = $value['account'];
                $record['passwd'] = $value['passwd'];
                $rolelist = $this->role->select_role(array('id' => $value['role_id']));
                $record['role_name'] = $rolelist[0]['name'];
                $regionlist = $this->region->select_region(array('admin_id' => $post_array['id']));
                $region_detail = null;
                foreach ($regionlist as $keyre => $valuere) {
                    $region_detail[] = $valuere['province'];
                }
                $record['region'] = $region_detail;
                $array[] = $record;
            }
            $this->admin->commit();
            $this->region->commit();
            $data['errcode'] = 0;
            $data['adminlist'] = $array;
            $data['msg'] = errCode::getErrText(0);
        } else {
            $data['errcode'] = -1006;
            $data['msg'] = errCode::getErrText(-1006);
        }

        echo json_encode($data);
    }

    public function login_admin()
    {
        $post_array['account'] = $_POST['account'];
        $post_array['passwd'] = $_POST['passwd'];
        if (!filters($post_array)) {
            $adminlist = $this->admin->select_admin($post_array);
            if (empty($adminlist)){
                $can='not';
            }else{
                $rolelist=$this->role->select_role(array('id' => $adminlist[0]['role_id']));
                if ($rolelist[0]['state']=='open'){
                    $can='yes';
                    $data['admin_id']=$adminlist[0]['id'];
                    $data['admin_name']=$adminlist[0]['name'];
                    $data['role_name']=$rolelist[0]['name'];
                    $data['power']=json_decode($rolelist[0]['power'],true);
                }else{
                    $can='not';
                }
            }
            $data['errcode'] = 0;
            $data['can'] = $can;
            $data['msg'] = errCode::getErrText(0);
        } else {
            $data['errcode'] = -1006;
            $data['msg'] = errCode::getErrText(-1006);
        }

        echo json_encode($data);
    }

    public function update_passwd()
    {
        $post_array['admin_id'] = $_POST['admin_id'];
        $post_array['ori_passwd'] = $_POST['ori_passwd'];
        $post_array['new_passwd'] = $_POST['new_passwd'];

        if (!filters($post_array)) {
            $adminlist = $this->admin->select_admin(array('id'=>$post_array['admin_id'],'passwd'=>$post_array['ori_passwd']));
            if (empty($adminlist)){
                $can='no';
            }else{
                $can='yes';
                $updateMethod = array($this->admin, 'update_passwd');
                Event::listen($updateMethod, $post_array['new_passwd'], $post_array['admin_id']);
            }
            $this->admin->commit();
            $this->region->commit();
            $data['errcode'] = 0;
            $data['can'] = $can;
            $data['msg'] = errCode::getErrText(0);
        } else {
            $data['errcode'] = -1006;
            $data['msg'] = errCode::getErrText(-1006);
        }
        echo json_encode($data);
    }
    
}